/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./myPcf/index.ts":
/*!************************!*\
  !*** ./myPcf/index.ts ***!
  \************************/
/***/ ((__unused_webpack_module, exports) => {

eval("\n\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.myPcf = void 0;\n\nvar myPcf =\n/** @class */\nfunction () {\n  function myPcf() {\n    var _this = this;\n\n    this.popUpClick = function () {\n      _this._popUpService.openPopup(\"CustomPopUp1\");\n    };\n\n    this.yesButton = function () {\n      //@ts-ignore\n      var focusedSession = Microsoft.Apm.getFocusedSession();\n\n      if (focusedSession != undefined || focusedSession != null) {\n        focusedSession.Close();\n      }\n\n      _this._popUpService.closePopup(\"CustomPopUp1\");\n    };\n\n    this.closeCustomPopUp = function () {\n      _this._popUpService.closePopup(\"CustomPopUp1\");\n    };\n  }\n  /**\r\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\r\n   * Data-set values are not initialized here, use updateView.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\r\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\r\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\r\n   * @param container If control is marked control-type='standard', it receives an empty div element within which it can render its content.\r\n   */\n\n\n  myPcf.prototype.init = function (context, notifyOutputChanged, state, container) {\n    var _this = this;\n\n    this._container = container; // if (!this._isUpdateViewCalled) {\n\n    var htmlContainer;\n    var quickViewButton;\n    var popUpContent;\n    var popUpContent1;\n    var closeButton;\n    var yesButton; //============ content of our popup =============\n\n    htmlContainer = document.createElement('div'); //button to show our popup\n\n    quickViewButton = document.createElement('button');\n    quickViewButton.innerHTML = \"Quick View\";\n    quickViewButton.classList.add('button');\n\n    quickViewButton.onclick = function () {\n      return _this.popUpClick();\n    };\n\n    htmlContainer.appendChild(quickViewButton); //@ts-ignore\n\n    var page = context.page;\n    var entityId = page.entityId;\n    popUpContent = document.createElement('div');\n    popUpContent.innerHTML = \"Close the session!\";\n    popUpContent.classList.add(\"container1\");\n    closeButton = document.createElement('button');\n    closeButton.innerHTML = \"Close\";\n    closeButton.classList.add('closeButton');\n\n    closeButton.onclick = function () {\n      return _this.closeCustomPopUp();\n    }; // Yes\n\n\n    yesButton = document.createElement('button');\n    yesButton.innerHTML = \"Yes\";\n    yesButton.classList.add('yesButton');\n\n    yesButton.onclick = function () {\n      return _this.yesButton();\n    };\n\n    popUpContent1 = document.createElement('div');\n    popUpContent1.appendChild(yesButton);\n    popUpContent1.appendChild(closeButton);\n    popUpContent.appendChild(popUpContent1); // Popup object\n\n    var popUpOptions = {\n      closeOnOutsideClick: true,\n      content: popUpContent,\n      name: 'CustomPopUp1',\n      type: 1,\n      popupProp: {},\n      popupStyle: {}\n    };\n    this._popUpService = context.factory.getPopupService();\n\n    this._popUpService.createPopup(popUpOptions);\n\n    container.appendChild(htmlContainer);\n  };\n  /**\r\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\r\n   */\n\n\n  myPcf.prototype.updateView = function (context) {// Add code to update control view\n  };\n  /**\r\n   * It is called by the framework prior to a control receiving new data.\r\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as “bound” or “output”\r\n   */\n\n\n  myPcf.prototype.getOutputs = function () {\n    return {};\n  };\n  /**\r\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\r\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\r\n   */\n\n\n  myPcf.prototype.destroy = function () {// Add code to cleanup control if necessary\n  };\n\n  return myPcf;\n}();\n\nexports.myPcf = myPcf;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./myPcf/index.ts?");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./myPcf/index.ts"](0, __webpack_exports__);
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('bhanu.myPcf', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.myPcf);
} else {
	var bhanu = bhanu || {};
	bhanu.myPcf = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.myPcf;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}